CREATE TABLE [dbo].[FunctionalRejects](
	[RejectDate] [datetime] NULL,
	[RejectPackageAndTask] [nvarchar](201) NULL,
	[RejectColumn] [nvarchar](50) NULL,
	[RejectDescription] [nvarchar](90) NULL,
	[nb_rejects] [numeric](20, 0) NULL
)

CREATE TABLE [dbo].[TechnicalsReject](
	[RejectDate] [datetime] NULL,
	[RejectPackageAndTask] [nvarchar](201) NULL,
	[RejectColumn] [nvarchar](255) NULL,
	[RejectDescription] [nvarchar](286) NULL
)