CREATE TABLE [dbo].[Call_Charges](
	[Call Type ] [varchar](255) NULL,
	[Call Charges (2018)] [varchar](255) NULL,
	[Call Charges (2019)] [varchar](255) NULL,
	[Call Charges (2020)] [varchar](255) NULL,
	[Call Charges (2021)] [varchar](255) NULL
) 
CREATE TABLE [dbo].[Call_Types](
	[CallTypeID] [varchar](255) NULL,
	[CallTypeLabel] [varchar](255) NULL
)
CREATE TABLE [dbo].[Data_2018](
	[CallTimestamp] [varchar](255) NULL,
	[Call Type] [varchar](255) NULL,
	[EmployeeID] [varchar](255) NULL,
	[CallDuration] [varchar](255) NULL,
	[WaitTime] [varchar](255) NULL,
	[CallAbandoned] [varchar](255) NULL
) 
CREATE TABLE [dbo].[Data_2019](
	[CallTimestamp] [varchar](255) NULL,
	[Call Type] [varchar](255) NULL,
	[EmployeeID] [varchar](255) NULL,
	[CallDuration] [varchar](255) NULL,
	[WaitTime] [varchar](255) NULL,
	[CallAbandoned] [varchar](255) NULL
)

CREATE TABLE [dbo].[Data_2020](
	[CallTimestamp] [varchar](255) NULL,
	[Call Type] [varchar](255) NULL,
	[EmployeeID] [varchar](255) NULL,
	[CallDuration] [varchar](255) NULL,
	[WaitTime] [varchar](255) NULL,
	[CallAbandoned] [varchar](255) NULL
)
CREATE TABLE [dbo].[Employees](
	[EmployeeID] [varchar](255) NULL,
	[EmployeeName] [varchar](255) NULL,
	[Site] [varchar](255) NULL,
	[ManagerName] [varchar](255) NULL
)
CREATE TABLE [dbo].[States](
	[StateCD] [varchar](255) NULL,
	[Name] [varchar](255) NULL,
	[Region] [varchar](255) NULL
) 