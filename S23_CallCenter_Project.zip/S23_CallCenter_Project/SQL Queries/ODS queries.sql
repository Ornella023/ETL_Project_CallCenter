CREATE TABLE [dbo].[CallsCharges](
	[CallTypeId] [int] NULL,
	[Call Type] [nvarchar](50) NULL,
	[Charges] [nvarchar](50) NULL,
	[Year] [int] NULL
)

CREATE TABLE [dbo].[CallsData](
	[CallTimestamp] [nvarchar](50) NULL,
	[Call Type] [int] NULL,
	[EmployeeID] [nvarchar](50) NULL,
	[CallDuration] [int] NULL,
	[WaitTime] [int] NULL,
	[CallAbandoned] [int] NULL,
	[Date] [date] NULL,
	[Time] [time](7) NULL
)
CREATE TABLE [dbo].[Employee](
	[EmployeeID] [nvarchar](10) NULL,
	[EmployeeName] [nvarchar](50) NULL,
	[EmployeeFirstName] [nvarchar](50) NULL,
	[EmployeeLastName] [nvarchar](50) NULL,
	[ManagerName] [nvarchar](50) NULL,
	[SiteCity] [nvarchar](50) NULL,
	[StateCD] [nvarchar](10) NULL,
	[StateName] [nvarchar](50) NULL,
	[Region] [nvarchar](50) NULL
)