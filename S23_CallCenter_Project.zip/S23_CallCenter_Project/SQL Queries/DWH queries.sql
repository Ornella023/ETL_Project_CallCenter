CREATE TABLE [dbo].[DimCallsCharges](
	[CallsChargesKey] [int] IDENTITY(1,1) NOT NULL,
	[CallTypeId] [int] NULL,
	[Call Type] [nvarchar](50) NULL,
	[Charges] [nvarchar](50) NULL,
	[Year] [nvarchar](10) NULL,
) 
CREATE TABLE [dbo].[DimEmployee](
	[EmployeeKey] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeID] [nvarchar](10) NULL,
	[EmployeeName] [nvarchar](50) NULL,
	[EmployeeFirstName] [nvarchar](50) NULL,
	[EmployeeLastName] [nvarchar](50) NULL,
	[ManagerName] [nvarchar](50) NULL,
	[SiteCity] [nvarchar](50) NULL,
	[StateCD] [nvarchar](10) NULL,
	[StateName] [nvarchar](50) NULL,
	[Region] [nvarchar](50) NULL,
)


CREATE TABLE [dbo].[FactCall](
	[CallKey] [int] IDENTITY(1,1) NOT NULL,
	[Call Type] [int] NULL,
	[EmployeeKey1] [int] NULL,
	[CallsChargesKey1] [int] NULL,
	[DateKey] [int] NULL,
	[TimeKey] [int] NULL,
	[Year(Date)] [nvarchar](20) NULL,
	[CallDuration] [int] NULL,
	[WaitTime] [int] NULL,
	[within SLA] [int] NULL,
	[CallAbandoned] [int] NULL
	
)
